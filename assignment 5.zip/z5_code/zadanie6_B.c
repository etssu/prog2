/**
        Compile with:   gcc main.c -o z6 -lncurses
        Must sure that items.json is located in the same folder as the compiled file.
            ALL RANGE STATS WILL BE 1 or 2.
            ALL RADIUS STATS WILL BE 0, 1, 2 or 3.
**/

#include <ctype.h>
#include <curses.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#define MENU_WIDTH 50
#define MENU_HEIGHT 15
#define LOGO_LINES 12
#define BUTTON_WIDTH 22
#define INFO_WIDTH 34
#define INFO_HEIGHT 18
#define CELL_WIDTH 9
#define CELL_HEIGHT 5
#define FIELD_ROWS 5
#define FIELD_COLS 2

#define MAX_NAME 16
#define MAX_ARMY 5
#define MIN_ARMY 1
#define MAX_LINE 256

#define ITEMS_FILE "items.json"

int item_count = 0;

typedef struct item {
    char name[MAX_NAME + 1];
    int att;
    int def;
    int slots;
    int range;
    int radius;
} ITEM;

typedef struct unit {
    char name[MAX_NAME + 1];
    const ITEM *item1;
    const ITEM *item2;
    int hp;
    int id;
} UNIT;

typedef struct battlefield {
    WINDOW *cells[FIELD_ROWS][FIELD_COLS * 2];
    UNIT *field[FIELD_ROWS][FIELD_COLS * 2];
} Battlefield;

typedef struct log_window {
    WINDOW *frame;
    WINDOW *text;
    int lines;
    int cols;
    int cursor_y;
} LOG_WINDOW;

typedef struct army_window {
    WINDOW *frame;
    WINDOW *text;
    int lines;
    int cols;
} ARMY_WINDOW;

// wanted to make sleep() command
struct timespec ts = {0, 300 * 1000000};

const char *logo[] = {
    "  ____        _   _   _         ",
    " |  _ \\      | | | | | |        ",
    " | |_) | __ _| |_| |_| | ___    ",
    " |  _ < / _` | __| __| |/ _ \\   ",
    " | |_) | (_| | |_| |_| |  __/   ",
    " |____/ \\__,_|\\__|\\__|_|\\___|   ",
    "     /\\                         ",
    "    /  \\   _ __ ___ _ __   __ _ ",
    "   / /\\ \\ | '__/ _ \\ '_ \\ / _` |",
    "  / ____ \\| | |  __/ | | | (_| |",
    " /_/    \\_\\_|  \\___|_| |_|\\__,_|",
    ""
};

const char *menu_items[] = {"Start Game",
                            "Load Game",
                            "Exit"};
#define MENU_ITEMS 3


// LOGS
LOG_WINDOW *create_log_window(const int height, const int width, const int starty, const int startx) {
    LOG_WINDOW *log = malloc(sizeof(LOG_WINDOW));
    log->lines = height - 4;
    log->cols = width - 4;
    log->cursor_y = 0;

    log->frame = newwin(height, width, starty, startx);
    log->text = newwin(log->lines, log->cols, starty + 2, startx + 2);

    wbkgd(log->frame, COLOR_PAIR(4));
    wbkgd(log->text, COLOR_PAIR(4));
    scrollok(log->text, TRUE);

    return log;
}

void log_message(LOG_WINDOW *log, const char *format, ...) {
    char buffer[256];
    va_list args;

    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);

    if (log->cursor_y >= log->lines) {
        scroll(log->text);
        log->cursor_y = log->lines - 1;
    }

    mvwprintw(log->text, log->cursor_y++, 0, "%s", buffer);
    wrefresh(log->text);
}

void del_log_window(LOG_WINDOW *log) {
    delwin(log->text);
    delwin(log->frame);
    free(log);
}
// LOGS


// ARMY INFO WINDOWS
ARMY_WINDOW *create_army_window(const int height, const int width, const int starty, const int startx) {
    ARMY_WINDOW *army = malloc(sizeof(ARMY_WINDOW));
    army->lines = height - 3;
    army->cols = width - 4;

    army->frame = newwin(height, width, starty, startx);
    army->text = newwin(army->lines, army->cols, starty + 2, startx + 2);

    wbkgd(army->frame, COLOR_PAIR(4));
    wbkgd(army->text, COLOR_PAIR(4));

    return army;
}

void update_army_window_general(ARMY_WINDOW *army, UNIT *units, const int count, const int color) {
    werase(army->text);

    wattron(army->text, COLOR_PAIR(color));
    for (int i = 0; i < count; i++) {
        int item1_len = (int)strlen(units[i].item1 ? units[i].item1->name : "");
        int item2_len = (units[i].item2 && strcmp(units[i].item2->name, "(nothing)") != 0)
                        ? (int)strlen(units[i].item2->name) : 0;


        mvwprintw(army->text, i*3, 0, "[%i]: %s - %i HP", i+1, units[i].name, units[i].hp);

        if (units[i].item2 && strcmp(units[i].item2->name, "(nothing)") != 0)
            mvwprintw(army->text, i*3 +1, (army->cols - 5 - item1_len - item2_len) / 2, "{%s , %s}", units[i].item1->name, units[i].item2->name);
        else
            mvwprintw(army->text, i*3 +1, (army->cols - 5 - item1_len) / 2, "{ %s }", units[i].item1->name);


    }
    wattroff(army->text, COLOR_PAIR(color));

    wrefresh(army->text);
}

void update_army_window_selected(ARMY_WINDOW *army_win, UNIT *unit, const int color) {
    werase(army_win->text);
    wattron(army_win->text, COLOR_PAIR(color));

    // name
    int name_len = (int)strlen(unit->name);
    int x_center = (army_win->cols - 8 - name_len) / 2;
    mvwprintw(army_win->text, 0, x_center > 0 ? x_center : 0, "--{ %s }--", unit->name);

    // HP bar
    int filled = unit->hp / 10;
    int empty = 10 - filled;

    int hp_x = (army_win->cols - 20) / 2;
    mvwprintw(army_win->text, 2, hp_x > 0 ? hp_x : 0, "-+[%3d][", unit->hp);
    for (int i = 0; i < filled; i++) wprintw(army_win->text, "#");
    for (int i = 0; i < empty; i++) wprintw(army_win->text, " ");
    wprintw(army_win->text, "]+-");

    // stats
    int att = 0, def = 0, range1 = 0, radius1 = 0, range2 = 0, radius2 = 0;

    if (unit->item1) {
        att += unit->item1->att;
        def += unit->item1->def;
        range1 = unit->item1->range;
        radius1 = unit->item1->radius;
    }

    if (unit->item2 && strcmp(unit->item2->name, "(nothing)") != 0) {
        att += unit->item2->att;
        def += unit->item2->def;
        range2 = unit->item2->range;
        radius2 = unit->item2->radius;
    }

    mvwprintw(army_win->text, 4, 3, "ATTACK     : %2d", att);
    mvwprintw(army_win->text, 5, 3, "DEFENCE    : %2d", def);
    mvwprintw(army_win->text, 6, 3, "RANGE      : (%d/%d)", range1, range2);
    mvwprintw(army_win->text, 7, 3, "RADIUS     : (%d/%d)", radius1, radius2);


    mvwprintw(army_win->text, army_win->lines - 1, 2, "<< (item1/item2) stats >>");

    wattroff(army_win->text, COLOR_PAIR(color));
    wrefresh(army_win->text);
}

void del_arm_window(ARMY_WINDOW *army) {
    if (army) {
        delwin(army->text);
        delwin(army->frame);
        free(army);
    }
}
// ARMY INFO WINDOWS


void continue_text(WINDOW *input_win, const int y, const int x) {
    wmove(input_win, y, 1);
    whline(input_win, ACS_HLINE, x - 1);

    for (int i = 0; i < 7; i++) {
        mvwprintw(input_win, y, x, (i % 2 == 0) ? "[Press any key to continue]" : " Press any key to continue ");
        wrefresh(input_win);
        nanosleep(&ts, NULL);
    }
    flushinp();     // clears unregistered buffer
    wgetch(input_win);

    werase(input_win);
    box(input_win, 0, 0);
}

// Main menu
void draw_logo(const int starty, const int startx) {
    attron(COLOR_PAIR(3));
    for (int i = 0; i < LOGO_LINES; i++) {
        mvprintw(starty + i, startx, "%s", logo[i]);
    }
    attroff(COLOR_PAIR(3));
}

void draw_menu(WINDOW *menu_win, const int highlight) {
    werase(menu_win);
    box(menu_win, 0, 0);
    for (int i = 0; i < MENU_ITEMS; i++) {

        // color if selected
        if (i == highlight) wattron(menu_win, COLOR_PAIR(2));
        else wattron(menu_win, COLOR_PAIR(1));

        // buttons
        int padlen = (BUTTON_WIDTH - 2 - strlen(menu_items[i])) / 2;
        int x = (MENU_WIDTH - BUTTON_WIDTH) / 2;

        mvwprintw(menu_win, 2 + i * 4, x, "+--------------------+");
        if (strlen(menu_items[i]) % 2 != 0) mvwprintw(menu_win, 3 + i * 4, x, "|%*s%s%*s|", padlen+1, "", menu_items[i], padlen, "");
        else mvwprintw(menu_win, 3 + i * 4, x, "|%*s%s%*s|", padlen, "", menu_items[i], padlen, "");
        mvwprintw(menu_win, 4 + i * 4, x, "+--------------------+");

        if (i == highlight) wattroff(menu_win, COLOR_PAIR(2));
        else wattroff(menu_win, COLOR_PAIR(1));
    }
    wrefresh(menu_win);
}

// Making field with cells and units' ids.
void battlefield_placeholder(WINDOW *win, Battlefield *field, UNIT *army1, const int army1_count, UNIT *army2, const int army2_count, LOG_WINDOW *log) {
    int start_y = 5;
    int start_x1 = 6;
    int start_x2 = start_x1 + (CELL_WIDTH + 2) * FIELD_COLS + 6;

    WINDOW *labels[2];
    labels[0] = newwin(2, 8, start_y - 2, (start_x1 + CELL_WIDTH * 2 + 2) / 2 - 1);
    labels[1] = newwin(2, 8, start_y - 2, start_x2 + CELL_WIDTH - 3);

    // Setup cells
    for (int col = 0; col < FIELD_COLS * 2; col++) {
        int base_x = (col < FIELD_COLS) ? start_x1 + col * (CELL_WIDTH + 2) : start_x2 + (col - FIELD_COLS) * (CELL_WIDTH + 2);

        for (int row = 0; row < FIELD_ROWS; row++) {
            int y = start_y + row * (CELL_HEIGHT + 1);
            field->cells[row][col] = newwin(CELL_HEIGHT, CELL_WIDTH, y, base_x);
            box(field->cells[row][col], 0, 0);
            wrefresh(field->cells[row][col]);
        }
    }

    // Setup units
    int selected_row = 0;
    int selected_col = 0;
    bool current_army = 0; // 0 - Army 1, 1 - Army 2
    int unit_index = 0;

    keypad(win, TRUE);
    wrefresh(win);

    log_message(log, "Place units, starting from [1] and go on.");

    while (1) {
        // Recoloring cells if selected
        for (int col = 0; col < FIELD_COLS * 2; col++) {
            for (int row = 0; row < FIELD_ROWS; row++) {
                if (col < 2 && current_army == 0) {
                    wattron(labels[0], COLOR_PAIR(6));
                    wattroff(labels[1], COLOR_PAIR(6));

                    if (row == selected_row && col == selected_col) {
                        wattron(field->cells[row][col], COLOR_PAIR(6));
                    } else {
                        wattroff(field->cells[row][col], COLOR_PAIR(6));
                    }
                }

                if (col >= 2 && current_army == 1) {
                    wattroff(labels[0], COLOR_PAIR(6));
                    wattron(labels[1], COLOR_PAIR(6));

                    if (row == selected_row && col == selected_col) {
                        wattron(field->cells[row][col], COLOR_PAIR(6));
                    } else {
                        wattroff(field->cells[row][col], COLOR_PAIR(6));
                    }
                }

                box(field->cells[row][col], 0, 0);
                wrefresh(field->cells[row][col]);

                for (int i = 0; i < 2; i++) {
                    mvwprintw(labels[i], 0, 1, "Army %i", i + 1);
                    mvwprintw(labels[i], 1, 0, "========");
                    wrefresh(labels[i]);
                }
            }
        }

        // If setup ends
        if (current_army == 1 && unit_index == army2_count) break;

        // Reading button pressing
        int key = wgetch(win);

        switch (key) {
            case KEY_UP:
                selected_row = (selected_row - 1 + FIELD_ROWS) % FIELD_ROWS;
                break;
            case KEY_DOWN:
                selected_row = (selected_row + 1) % FIELD_ROWS;
                break;
            case KEY_LEFT:
                if (current_army == 0 && selected_col > 0) selected_col--;
                else if (current_army == 1 && selected_col > 2) selected_col--;
                break;
            case KEY_RIGHT:
                if (current_army == 0 && selected_col < FIELD_COLS - 1) selected_col++;
                else if (current_army == 1 && selected_col < FIELD_COLS*2 - 1) selected_col++;
                break;
            case 10: // Apply the unit's placement
                if (!field->field[selected_row][selected_col]) {
                    if (current_army == 0) {
                        field->field[selected_row][selected_col] = &army1[unit_index];
                        log_message(log, "%s was placed.", field->field[selected_row][selected_col]->name);
                    }
                    if (current_army == 1) {
                        field->field[selected_row][selected_col] = &army2[unit_index];
                        log_message(log, "%s was placed.", field->field[selected_row][selected_col]->name);
                    }
                    unit_index++;

                    mvwprintw(field->cells[selected_row][selected_col], 2, 3, "[%i]", unit_index);

                    if (current_army == 0 && unit_index == army1_count) {
                        current_army = 1;
                        selected_row = 0;
                        selected_col = 2;
                        unit_index = 0;
                    }
                }

                break;
        }
    }

    wrefresh(win);
}

//The fight and info rendering
void battlefield_simulation(WINDOW *win, Battlefield *field, ARMY_WINDOW *army_win[2], LOG_WINDOW *log,
                            UNIT *army1, UNIT *army2, const int count1, const int count2) {
    const int start_y = 5;
    const int start_x1 = 6;
    const int start_x2 = start_x1 + (CELL_WIDTH + 2) * FIELD_COLS + 6;

    // Make hint who is what army + their units info
    WINDOW *labels[2];
    labels[0] = newwin(2, 8, start_y - 2, (start_x1 + CELL_WIDTH * 2 + 2) / 2 - 1);
    labels[1] = newwin(2, 8, start_y - 2, start_x2 + CELL_WIDTH - 3);

    update_army_window_general(army_win[0], army1, count1, 5);
    update_army_window_general(army_win[1], army2, count2, 6);

    // print cells with units' id
    for (int col = 0; col < FIELD_COLS * 2; ++col) {
        int base_x = (col < FIELD_COLS) ? start_x1 + col * (CELL_WIDTH + 2)
                                        : start_x2 + (col - FIELD_COLS) * (CELL_WIDTH + 2);

        for (int row = 0; row < FIELD_ROWS; ++row) {
            int y = start_y + row * (CELL_HEIGHT + 1);
            field->cells[row][col] = newwin(CELL_HEIGHT, CELL_WIDTH, y, base_x);
            box(field->cells[row][col], 0, 0);

            UNIT *unit = field->field[row][col];
            if (unit) mvwprintw(field->cells[row][col], 2, 3, "[%i]", unit->id + 1);

            wrefresh(field->cells[row][col]);
        }
    }

    // ability selecting units
    int selected_row = 0;
    int selected_col = 0;
    bool current_army = 0;
    bool attacking = false;
    bool selection = false;

    keypad(win, TRUE);
    wrefresh(win);

    while (!attacking) {
        for (int i = 0; i < 2; ++i) {
            mvwprintw(labels[i], 0, 1, "Army %d", i + 1);
            mvwprintw(labels[i], 1, 0, "========");
            wrefresh(labels[i]);
        }

        // Recolor selected sells and show unit profiles
        if (selection) {
            for (int col = 0; col < FIELD_COLS * 2; ++col) {
                for (int row = 0; row < FIELD_ROWS; ++row) {
                    bool is_current_side = (col < FIELD_COLS && current_army == 0) || (col >= FIELD_COLS && current_army == 1);
                    if (!is_current_side) continue;

                    int color = current_army == 0 ? 5 : 6;
                    wattron(labels[current_army], COLOR_PAIR(6));
                    wattroff(labels[!current_army], COLOR_PAIR(6));

                    if (row == selected_row && col == selected_col) {
                        wattron(field->cells[row][col], COLOR_PAIR(6));

                        UNIT *unit = field->field[row][col];
                        if (unit) {
                            update_army_window_selected(army_win[current_army], unit, color);
                        } else {
                            werase(army_win[current_army]->text);
                            mvwprintw(army_win[current_army]->text, 0, (INFO_WIDTH - 4 - 17) / 2, "-- Select Unit --");
                            wrefresh(army_win[current_army]->text);
                        }
                    } else {
                        wattroff(field->cells[row][col], COLOR_PAIR(6));
                    }

                    box(field->cells[row][col], 0, 0);
                    wrefresh(field->cells[row][col]);
                }
            }
        }

        // watching for pressing button
        int key = wgetch(win);
        switch (key) {

            // key for selection
            case 'q':
            case 'Q':
                selection = !selection;
                log_message(log, selection ? "Unit reselection enabled." : "Unit reselection disabled.");

                if (!selection) {
                    update_army_window_general(army_win[0], army1, count1, 5);
                    update_army_window_general(army_win[1], army2, count2, 6);

                    for (int i = 0; i < 2; ++i) {
                        wattroff(labels[i], COLOR_PAIR(6));
                        mvwprintw(labels[i], 0, 1, "Army %d", i + 1);
                        mvwprintw(labels[i], 1, 0, "========");
                        wrefresh(labels[i]);
                    }
                } else {
                    selected_row = 0;
                    selected_col = 0;
                    current_army = 0;
                }
                break;

            case KEY_UP:
                if (selection) selected_row = (selected_row - 1 + FIELD_ROWS) % FIELD_ROWS;
                break;

            case KEY_DOWN:
                if (selection) selected_row = (selected_row + 1) % FIELD_ROWS;
                break;

            case KEY_LEFT:
                if (selection) {
                    if (current_army == 0 && selected_col > 0) selected_col--;
                    else if (current_army == 1 && selected_col > FIELD_COLS) selected_col--;
                }
                break;

            case KEY_RIGHT:
                if (selection) {
                    if (current_army == 0 && selected_col < FIELD_COLS - 1) selected_col++;
                    else if (current_army == 1 && selected_col < FIELD_COLS * 2 - 1) selected_col++;
                }
                break;

            case 10: // confirm the choice and switch army coll
                if (selection && field->field[selected_row][selected_col]) {
                    if (current_army == 0) {
                        current_army = 1;
                        selected_row = 0;
                        selected_col = FIELD_COLS;
                    } else {
                        attacking = true;
                    }
                }
                break;
        }
    }

    wrefresh(win);
}

// Menu with items for army creating
int select_item_menu(ITEM *items, const int starty, const int startx, const char *prompt) {
    int highlight = 0;
    int visible = item_count < INFO_HEIGHT - 2 ? item_count : INFO_HEIGHT - 2;

    WINDOW *menu = newwin(visible + 2, (INFO_WIDTH - 4)*2, starty, startx);
    keypad(menu, TRUE);

    while (1) {
        werase(menu);
        box(menu, 0, 0);
        mvwprintw(menu, 0, 2, "[ %s ]", prompt);

        // item row example
        for (int i = 0; i < visible; i++) {
            int idx = i + highlight;
            if (idx >= item_count) break;
            if (i == 0) wattron(menu, A_REVERSE);
            mvwprintw(menu, 1 + i, 2, "%-16s: ATT: %-2d DEF: %-2d SLT: %d RNG: %d RDS: %d", items[idx].name, items[idx].att, items[idx].def, items[idx].slots, items[idx].range, items[idx].radius);
            if (i == 0) wattroff(menu, A_REVERSE);
        }
        wrefresh(menu);

        // watching for pressing button
        const int key = wgetch(menu);
        switch (key) {
            case KEY_UP:
                if (highlight > 0) highlight--;
                break;
            case KEY_DOWN:
                if (highlight < item_count - 1) highlight++;
                break;
            case 10: // Enter
                werase(menu);
                wrefresh(menu);
                delwin(menu);
                return highlight;
            default: continue;
        }
    }
}

// Items loading from items.json
int load_items(ITEM *items) {
    FILE *chpok = fopen(ITEMS_FILE, "r");
    if (!chpok) return 0;

    items[0] = (ITEM){"(nothing)", 0, 0, 1, 1, 0};      // empty item, idk
    item_count = 1;

    char line[MAX_LINE + 1];

    while (fgets(line, sizeof(line), chpok)) {
        if (strchr(line, '{')) {
            ITEM item = {0};

            while (fgets(line, sizeof(line), chpok) && !strchr(line, '}')) {
                char *key = strtok(line, ":");
                char *value = strtok(NULL, ",");

                if (!key || !value) continue;

                // Clear cache
                while (*key && !isalpha(*key)) key++;
                while (*value == ' ' || *value == '"') value++;

                char *end = value + strlen(value) - 1;
                while (end > value && (*end == '\n' || *end == '\r' || *end == '"' || *end == ' ')) {
                    *end-- = '\0';
                }

                // Set stats
                if (strstr(key, "name")) {
                    strncpy(item.name, value, MAX_NAME);
                } else if (strstr(key, "att")) {
                    item.att = (int)strtol(value, NULL, 10);
                } else if (strstr(key, "def")) {
                    item.def = (int)strtol(value, NULL, 10);
                } else if (strstr(key, "slots")) {
                    item.slots = (int)strtol(value, NULL, 10);
                } else if (strstr(key, "range")) {
                    int range = (int)strtol(value, NULL, 10);
                    item.range = range >= 2 ? 2 : 1;
                } else if (strstr(key, "radius")) {
                    int radius = (int)strtol(value, NULL, 10);
                    item.radius = (radius > 3) ? 3 : radius;
                }
            }

            items[item_count++] = item;
        }
    }

    fclose(chpok);
    return 1;
}

// Creating army with console and items
void input_army(WINDOW *input_win, WINDOW *info_win, UNIT *army, int *count, const char *army_label, const int color_pair, ITEM *items, LOG_WINDOW *log) {
    static int input_line = 5;
    char buffer[128];
    echo();

    // enter count
    mvwprintw(input_win, input_line++, 2, "Enter %s unit count (1-5): ", army_label);
    input_line++;

    wrefresh(input_win);
    wgetnstr(input_win, buffer, sizeof(buffer)-1);
    *count = (int)strtol(buffer, NULL, 10);
    if (*count < MIN_ARMY) {
        mvwprintw(input_win, input_line++, 2, ">> Invalid unit count. Set to 1.");
        *count = 1;
    } else if (*count > MAX_ARMY) {
        mvwprintw(input_win, input_line++, 2, ">> Invalid unit count. Set to 5.");
        *count = 5;
    }

    // enter name
    for (int i = 0; i < *count; i++) {
        mvwprintw(input_win, input_line, 2, "Unit [%d] name (max 16): ", i+1);
        wrefresh(input_win);

        wgetnstr(input_win, buffer, MAX_NAME);
        buffer[MAX_NAME] = '\0';

        strncpy(army[i].name, buffer, MAX_NAME);
        army[i].name[MAX_NAME] = '\0';

        // clear window, if too trashy
        input_line++;
        if (input_line >= getmaxy(input_win) - 2) input_line = 1;

        // enter item from list
        int index1 = select_item_menu(items, 7, INFO_WIDTH*2 + INFO_WIDTH/3, "Select Item 1");
        const ITEM *item1 = &items[index1];

        const ITEM *item2 = NULL;
        if (item1->slots < 2) {
            int index2 = select_item_menu(items, 7, INFO_WIDTH*2 + INFO_WIDTH/3, "Select Item 2");
            item2 = &items[index2];

            while (item1->slots + item2->slots > 2) {
                log_message(log, "Too many slots used. Please, reselect item with less slots.");
                index2 = select_item_menu(items, 7, INFO_WIDTH*2 + INFO_WIDTH/3, "Reselect Item 2");
                item2 = &items[index2];
            }
        }

        // applying
        army[i].item1 = item1;
        army[i].item2 = item2;
        army[i].hp = 100;
        army[i].id = i;

        wattron(info_win, COLOR_PAIR(color_pair));

        // info output

        mvwprintw(info_win, i*3, 2, "[%i] %s:", i + 1, army[i].name);
        mvwprintw(info_win, 1 + i*3, 4, "- %s", army[i].item1->name);
        if (army[i].item2) mvwprintw(info_win, 2 + i*3, 4, "- %s", army[i].item2->name);
        else mvwprintw(info_win, 2 + i*3, 4, "- (none)");

        wattroff(info_win, COLOR_PAIR(color_pair));
        wrefresh(info_win);
    }

    noecho();
}

int start_game_screen() {
    clear();
    noecho();
    cbreak();
    curs_set(1);

    // WINDOWS: MAIN, INFOs, LOG

    int height, width;
    getmaxyx(stdscr, height, width);
    const int hints_height = height - (height - 2 - INFO_HEIGHT*2) - 3;

    start_color();

    bkgd(COLOR_PAIR(4));
    erase();
    box(stdscr, 0, 0);
    mvprintw(0, 2, "[Battle Arena - Game Screen]");

    const int left_w = width - INFO_WIDTH - 4;
    WINDOW *input_win = newwin(height - 2 - (height - 2 - INFO_HEIGHT*2), left_w, 1, 1);
    box(input_win, 0, 0);
    mvwprintw(input_win, 0, 2, "[ Console / Input ]");

    mvwprintw(input_win, 2, 2, "Please set up 2 armies. Each unit needs a name (up to 16 characters)");
    mvwprintw(input_win, 3, 2, "and two items, if you do not want to take the second item, take \"(nothing)\".");

    mvwprintw(input_win, hints_height, 12, "+[ [KEY_UP]: select above  [KEY_DOWN]: select below  [ENTER]: apply ]+");
    scrollok(input_win, TRUE);

    ARMY_WINDOW *army_win[2];
    army_win[0] = create_army_window(INFO_HEIGHT, INFO_WIDTH, 1, width - INFO_WIDTH - 2);
    army_win[1] = create_army_window(INFO_HEIGHT, INFO_WIDTH, INFO_HEIGHT + 1, width - INFO_WIDTH - 2);

    //WINDOW *army1_win = newwin(INFO_HEIGHT, INFO_WIDTH, 1, width - INFO_WIDTH - 2);
    box(army_win[0]->frame, 0, 0);
    wattron(army_win[0]->frame, COLOR_PAIR(5));
    mvwprintw(army_win[0]->frame, 0, 2, "[ Army 1 ]");
    wattroff(army_win[0]->frame, COLOR_PAIR(5));

    //WINDOW *army2_win = newwin(INFO_HEIGHT, INFO_WIDTH, INFO_HEIGHT + 1, width - INFO_WIDTH - 2);
    box(army_win[1]->frame, 0, 0);
    wattron(army_win[1]->frame, COLOR_PAIR(6));
    mvwprintw(army_win[1]->frame, 0, 2, "[ Army 2 ]");
    wattroff(army_win[1]->frame, COLOR_PAIR(6));

    //WINDOW *LOG_win = newwin(height - 2 - INFO_HEIGHT*2, width - 2, INFO_HEIGHT*2 + 1, 1);
    LOG_WINDOW *log_win = create_log_window(height - 2 - INFO_HEIGHT*2, width - 2, INFO_HEIGHT*2 + 1, 1);
    box(log_win->frame, 0, 0);
    wattron(log_win->frame, COLOR_PAIR(4));
    mvwprintw(log_win->frame, 0, 2, "[ LOG ]");
    wattroff(log_win->frame, COLOR_PAIR(4));

    wrefresh(stdscr);
    wrefresh(input_win);
    wrefresh(army_win[0]->frame);
    wrefresh(army_win[1]->frame);
    wrefresh(log_win->frame);

    log_message(log_win, "=== LOG INITIALIZED ===");

    // MAKING ARMY //

    ITEM items[100] = {0};
    if( !load_items(items) ) return 1;

    UNIT army1[MAX_ARMY]; int count1;
    UNIT army2[MAX_ARMY]; int count2;
    Battlefield battlefield;

    for (int i = 0; i < FIELD_ROWS; i++) {
        for (int j = 0; j < FIELD_COLS * 2; j++) {
            battlefield.cells[i][j] = NULL;
            battlefield.field[i][j] = NULL;
        }
    }

    input_army(input_win, army_win[0]->text, army1, &count1, "Army 1", 5, items, log_win);
    input_army(input_win, army_win[1]->text, army2, &count2, "Army 2", 6, items, log_win);

    continue_text(input_win, hints_height, INFO_WIDTH*3);

    // DEPLOYING ARMY
    mvwprintw(input_win, 0, 2, "[ Battlefield Grid ]");
    mvwprintw(input_win, hints_height, 12, "+[ [KEY_UP]: to above  [KEY_DOWN]: to below  [KEY_LEFT]: to left  [KEY_RIGHT]: to right  [ENTER]: apply ]+");
    wrefresh(input_win);
    battlefield_placeholder(input_win, &battlefield, army1, count1, army2, count2, log_win);

    continue_text(input_win, hints_height, INFO_WIDTH*3);

    // FIGHTING
    mvwprintw(input_win, 0, 2, "[ Battlefield Simulation ]");
    mvwprintw(input_win, hints_height, 12, "+[ [KEY_UP]: to above  [KEY_DOWN]: to below  [KEY_LEFT]: to left  [KEY_RIGHT]: to right  [ENTER]: apply  [Q]: selection]+");
    wrefresh(input_win);
    battlefield_simulation(input_win, &battlefield, army_win, log_win, army1, army2, count1, count2);

    continue_text(input_win, hints_height, INFO_WIDTH*3 + 4);


    // END

    del_log_window(log_win);
    delwin(input_win);
    del_arm_window(army_win[0]);
    del_arm_window(army_win[1]);
    clear();
    refresh();
    endwin();

    printf("I am so sorry, but i can not finish this project, because of time and exams. \nThank you for playing a piece of design code.\n");
    return 0;
}

int main() {
    initscr();
    clear();
    noecho();
    cbreak();
    curs_set(0);

    if (!has_colors()) {
        endwin();
        printf("Your terminal does not support color\n");
        return 1;
    }

    start_color();
    init_pair(1, COLOR_WHITE, COLOR_BLUE);    // normal buttons
    init_pair(2, COLOR_BLACK, COLOR_YELLOW);  // highlighted button
    init_pair(3, COLOR_RED, COLOR_BLACK);     // logo
    init_pair(4, COLOR_WHITE, COLOR_BLACK);   // border, others
    init_pair(5, COLOR_CYAN, COLOR_BLACK);
    init_pair(6, COLOR_YELLOW, COLOR_BLACK);

    int height, width;
    getmaxyx(stdscr, height, width);

    const int menu_startx = (width - MENU_WIDTH) / 3;
    const int menu_starty = (height - MENU_HEIGHT) / 2;

    WINDOW *menu_win = newwin(MENU_HEIGHT, MENU_WIDTH, menu_starty, menu_startx);
    keypad(menu_win, TRUE);
    wbkgd(menu_win, COLOR_PAIR(4));

    int highlight = 0;
    int choice;

    // draw menu: frame and logo
    box(stdscr, 0, 0);
    attron(COLOR_PAIR(4));
    mvprintw(0, 2, "[ Battle Arena 3.0 ]");
    attroff(COLOR_PAIR(4));
    draw_logo(menu_starty, menu_startx + MENU_WIDTH + 8);
    refresh();

    while (1) {     //mode selection
        draw_menu(menu_win, highlight);

        const int key = wgetch(menu_win);
        switch (key) {
            case KEY_UP:
                highlight = (highlight - 1 + MENU_ITEMS) % MENU_ITEMS;
                break;
            case KEY_DOWN:
                highlight = (highlight + 1) % MENU_ITEMS;
                break;
            case 10: // Enter
                choice = highlight;
                goto end_loop;
            default: continue;
        }

    }

end_loop:
    delwin(menu_win);

    switch (choice) {
        case 0:
            //printf("Start Game selected\n");
            start_game_screen();
            endwin();
            break;
        case 1:
            printf("Did not have time to finish that function. Process ended.\n");
            endwin();
            break;
        case 2:
            //printf("Exit selected\n");
            endwin();
            break;
        default: ;
    }

    return 0;
}
