#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "data.h" // NEMENIT, inak vas kod neprejde testom !!!

// chybove hlasenia
#define ERR_UNIT_COUNT "ERR_UNIT_COUNT"
#define ERR_ITEM_COUNT "ERR_ITEM_COUNT"
#define ERR_WRONG_ITEM "ERR_WRONG_ITEM"
#define ERR_SLOTS "ERR_SLOTS"
#define MAX_ITEM 2

#define LEFT_WIDTH 21

ITEM* find_item(char *name) {
    for (int i = 0; i < NUMBER_OF_ITEMS; i++) {
        if (strcmp(items[i].name, name) == 0) {
            return &items[i];

        }
    }
    return NULL;
}

void load_character(struct unit *unit) {
    char extra[MAX_NAME];
    char line[400];
    char item1_name[MAX_NAME];
    char item2_name[MAX_NAME];

    fgets(line, sizeof(line), stdin);

    int count = sscanf(line , "%s %s %s %s", unit->name, item1_name, item2_name, extra); // nacitanie jednotky
    unit->hp = 100; // nastavime HP na 100

    if (count < 2 || count > 3) {
        printf("%s\n", ERR_ITEM_COUNT);
        exit(0); // chyba: menej ako 2 alebo viac ako 3 slová
    }

    // find_item(unit->item1);
    unit->item1 = find_item(item1_name);
    if (!unit->item1) {
        printf("%s\n", ERR_WRONG_ITEM);
        exit(1);
    }

    if (count == 3) {
        // druhý predmet je, nastavíme na prázdny reťazec
        unit->item2 = find_item(item2_name);
        if (!unit->item2) {
            printf("%s\n", ERR_WRONG_ITEM);
            exit(1);
        }
    } else {
        // druhý predmet nie je, nastavíme na prázdny reťazec
        unit->item2 = NULL;
    }

    if (unit->item1->slots + (unit->item2 ? unit->item2->slots : 0) > MAX_ITEM) {
        printf("%s\n", ERR_SLOTS);
        exit(0); // chyba: počet slotov presahuje maximálny počet
    }
};


void load_unit(UNIT *army, int *number_of_units) {
    int units = 0; // pocet jednotiek
    scanf("%d", &units); // nacitanie poctu jednotiek
    getchar();

    if (units < MIN_ARMY || units > MAX_ARMY) {
        printf("%s\n", ERR_UNIT_COUNT);
        exit(0);
    }

    for (int i = 0; i < units; i++) {
        load_character(&army[i]);

    }
    *number_of_units = units; // nastavime pocet jednotiek
};

void load_units(UNIT *army1, UNIT *army2, int *number_of_units1, int *number_of_units2) {
    // printf("army1\n");
    load_unit(army1, number_of_units1);
    // printf("army2\n");
    load_unit(army2, number_of_units2);
};

void print_unit_start(UNIT *unit, int number_of_units) {
    // printf("number of units: %d\n", number_of_units);

    for (int i = 0; i < number_of_units; i++) {
        UNIT u = unit[i];
        printf("    Unit: %d\n", i);
        printf("    Name: %s\n", u.name);
        printf("    HP: %d\n", u.hp);
        printf("    Item 1: %s,%d,%d,%d,%d,%d\n",
               u.item1->name,
               u.item1->att,
               u.item1->def,
               u.item1->slots,
               u.item1->range,
               u.item1->radius);
        if (u.item2 != NULL) {
            printf("    Item 2: %s,%d,%d,%d,%d,%d\n",
               u.item2->name,
               u.item2->att,
               u.item2->def,
               u.item2->slots,
               u.item2->range,
               u.item2->radius);
        }
        printf("\n");
    }

}



void print_units_start(UNIT *army1, UNIT *army2, int number_of_units1, int number_of_units2) {
    printf("Army 1\n");
    print_unit_start(army1, number_of_units1);
    printf("Army 2\n");
    print_unit_start(army2, number_of_units2);

};

void print_unit(UNIT *unit, int number_of_units) {
    for (int i = 0; i < number_of_units; i++) {
        if (unit[i].hp <= 0) {
            continue; // ak je HP <= 0, preskocime
        }
        printf("%s,%d ", unit[i].name, unit[i].hp);
    }
    printf("\n");
}

void print_units(UNIT *army1, UNIT *army2, int number_of_units1, int number_of_units2) {
    printf("1: ");
    print_unit(army1, number_of_units1);
    printf("2: ");
    print_unit(army2, number_of_units2);
};


void update_army(UNIT *army, int *number_of_units) {
    int alive_index = 0;

    for (int i = 0; i < *number_of_units; i++) {
        if (army[i].hp > 0) {
            // Jednotka je živá, presuň ju dopredu
            if (i != alive_index) {
                army[alive_index] = army[i];
            }
            alive_index++;
        }
    };
    *number_of_units = alive_index;
}


void attack_army(UNIT *attacking, UNIT *defending, int num_attacking, int num_defending, int army) {
    for (int i = 0; i < num_attacking; i++) {
        // if (attacking[i].hp <= 0) continue;

        ITEM *items[2] = { attacking[i].item1, attacking[i].item2 };

        for (int k = 0; k < 2; k++) {
            ITEM *item = items[k];
            if (!item) continue;

            if (item->range >= i) { // jednotka môže útočiť
                // printf("%d,%s,%s:    ", army, attacking[i].name, item->name);

                char left[100];
                int len = snprintf(left, sizeof(left), "%d,%s,%s:", army, attacking[i].name, item->name);

                // 🔹 Vypíšeme ľavú časť
                printf("%s", left);

                // 🔹 Doplnenie medzier do pevnej šírky
                for (int s = len; s < LEFT_WIDTH; s++) {
                    printf(" ");
                }


                int hits = 0;

                for (int j = 0; j <= item->radius; j++) {
                    if (j >= num_defending) break;

                    // ⚠️ Odstránená kontrola na hp <= 0

                    int damage = item->att - defending[j].item1->def;
                    if (defending[j].item2) {
                        damage -= defending[j].item2->def;
                    }
                    if (damage < 1) damage = 1;

                    defending[j].hp -= damage;
                    if (defending[j].hp < 0) defending[j].hp = 0;

                    printf("[%s,%d] ", defending[j].name, damage);
                    hits++;
                }

                if (hits == 0) {
                    printf("no valid targets");
                }

                printf("\n");
            }
        }
    }
}



int is_game_over(UNIT *army1, UNIT *army2, int number_of_units1, int number_of_units2) {
    int alive1 = 0;
    int alive2 = 0;

    // Spočítame živé jednotky v armáde 1
    for (int i = 0; i < number_of_units1; i++) {
        if (army1[i].hp > 0) {
            alive1++;
        }
    }

    // Spočítame živé jednotky v armáde 2
    for (int i = 0; i < number_of_units2; i++) {
        if (army2[i].hp > 0) {
            alive2++;
        }
    }

    if (alive1 == 0 && alive2 == 0) {
        printf("NO WINNER\n");
        return 1;
    } else if (alive1 == 0) {
        printf("WINNER: 2\n");
        return 1;
    } else if (alive2 == 0) {
        printf("WINNER: 1\n");
        return 1;
    }

    return 0; // Hra pokračuje
};



int main(const int argc, char *argv[]) {

    int number_of_rounds = 0;
    if (argc == 2) {
        number_of_rounds = atoi(argv[1]);
    }


    // printf("     %d\n", number_of_rounds);

    UNIT army1[MAX_ARMY]; // armada 1
    UNIT army2[MAX_ARMY]; // armada 2
    int number_of_units1 = 0, number_of_units2 = 0; // pocet jednotiek

    load_units(army1, army2, &number_of_units1, &number_of_units2); // nacitanie armad
    print_units_start(army1, army2, number_of_units1, number_of_units2); // vypis armad na zaciatku


    int round = 1;
    while(!is_game_over(army1, army2, number_of_units1, number_of_units2) ) {

        if (number_of_rounds == 0 && argc == 2) {
            break;
        }

        printf("Round %d\n", round);

        print_units(army1, army2, number_of_units1, number_of_units2); // vypis armad na zaciatku kola

        attack_army(army1, army2, number_of_units1, number_of_units2, 1); // armada 1 vykona utok
        attack_army(army2, army1, number_of_units2, number_of_units1, 2); // armada 2 vykona utok

        update_army(army1, &number_of_units1);
        update_army(army2, &number_of_units2);

        print_units(army1, army2, number_of_units1, number_of_units2); // vypis armad na konci kola



        round++;
        printf("\n");

        if (round > number_of_rounds && number_of_rounds != 0) {
            break;
        }

    }



    return 0;
}
